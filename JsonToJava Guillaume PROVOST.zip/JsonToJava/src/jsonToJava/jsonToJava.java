package jsonToJava;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.internal.runners.ErrorReportingRunner;

public class jsonToJava {

	public static void main(String[] args) {
		List<Object> liste = new ArrayList<>();
		Map<String,Object>objet1 =new HashMap<>();
		objet1.put("Key1", 1);
		objet1.put("key2", "test1");
		liste.add(objet1);
		
		Map<String,Object>objet2 =new HashMap<>();
		objet2.put("Key1", 1);
		objet2.put("key2", "test2");
		liste.add(objet2);
		
		//Class <T> classeResultat=;
		//Object t = toJava(liste, classeResultat);
		//System.out.println(t);
	}

	@SuppressWarnings("unchecked")
	public static<T> T toJava(Object objet, Class<T> classe1) {
		if(Boolean.class.equals(classe1)) {
			return (T)objet;
		}
		else if(Integer.class.equals(classe1)) {
			return (T)objet; 
		}
		else if(Double.class.equals(classe1)) {
			return (T)objet; 
		}
		else if(String.class.equals(classe1)) {
			return (T)objet;
		}
		else if(Collection.class.isAssignableFrom(classe1)) {
			return (T)objet;
		}
		else {
			T resultat;
			try {
				resultat = classe1.newInstance();
			}
			catch (InstantiationException e) {
				throw new RuntimeException("cr�ation d'une nouvelle instance impossible", e);
			} 
			catch (IllegalAccessException e) {
				throw new RuntimeException("cr�ation d'une nouvelle instance impossible", e);
	
			}
			Map<String, Object> valeursChamps = (Map<String,Object>) objet;
			for(Map.Entry<String, Object> e : valeursChamps.entrySet() ) {
				String nomChamps = e.getKey();
				Object valeurChampJson = e.getValue();
				Field champ = null;
				try {
					champ = classe1.getField(nomChamps);
				} 
				catch (NoSuchFieldException | SecurityException e1) {
					throw new RuntimeException(e1);
				}
				try {
					champ.set(resultat, toJava(valeurChampJson,champ.getType()));
				}
				catch(Exception e1) {
				}
				
			}
			return resultat;
		}
		
	}
}
class T {
	Object obj;
	public T (Object obj) {
		this.obj=obj;
	}
}
