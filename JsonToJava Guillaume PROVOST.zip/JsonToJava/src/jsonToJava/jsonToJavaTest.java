package jsonToJava;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;


public class jsonToJavaTest {

	public void setUp() throws Exception {
	}

	public static class Utilisateurs {
		public String nom;
		public Addresse addresse;

		public Utilisateurs(String nom, Addresse adresse) {
			this.nom = nom;
			this.addresse = adresse;
		}

		public Utilisateurs(String nom) {
			this.nom = nom;
		}

		public Utilisateurs() {

		}

		@Override
		public boolean equals(Object objet) {
			if (this == objet) {
				return true;
			}
			if (objet == null) {
				return false;
			}
			if (getClass() != objet.getClass()) {
				return false;
			}
			Utilisateurs other = (Utilisateurs) objet;
			if (nom == null) {
				if (other.nom != null) {
					return false;
				}
			} 
			else if (!nom.equals(other.nom)) {
				return false;
			}
			return true;
		}

	}

	public static class Addresse {
		public String codePostal;
		public String voie;

		public Addresse(String codePostal, String voie) {
			this.codePostal = codePostal;
			this.voie = voie;
		}

	}

	@Test
	public void testBoolean() {
		Assert.assertEquals(true, jsonToJava.toJava(true, Boolean.class));
	}

	@Test
	public void testString() {
		Assert.assertEquals("Guillaume", jsonToJava.toJava("Guillaume", String.class));
	}

	@Test
	public void integerTest() {
		Assert.assertEquals(Integer.valueOf(8), jsonToJava.toJava(8, Integer.class));
	}
	
	@Test
	public void doubleTest() {
		Assert.assertEquals(Double.valueOf(8.55), jsonToJava.toJava(8.55, Double.class));
	}

	@Test
	public void testUser() {
		Map<String, Object> map = new HashMap<>();
		map.put("nom", "Guillaume");
		Assert.assertEquals(new Utilisateurs("Guillaume", new Addresse("93100", "Madeline")), jsonToJava.toJava(map, Utilisateurs.class));

	}

	@Test
	public void mapTest() {
		Map<String, Object> map = new HashMap<>();
		map.put("nom", "Guillaume");
		Addresse a =  new Addresse("93150", "Madeline");
		Utilisateurs u = new Utilisateurs("Guillaume", a);
		Utilisateurs u2 = jsonToJava.toJava(map, Utilisateurs.class);
		Assert.assertEquals(u , u2);
	}

	@Test
	public void addressTest() {
		Map<String, Object> map = new HashMap<>();
		map.put("nom", "Guillaume");
		{
			Map<String, Object> mapAdresse = new HashMap<>();
			map.put("addresse", mapAdresse);

			mapAdresse.put("codePostal", "93100");
			mapAdresse.put("voie", "Madeline");
		}
		Addresse a = new Addresse("93150", "Madeline");
		Utilisateurs u = new Utilisateurs("Guillaume", a);
		Utilisateurs u2 = jsonToJava.toJava(map, Utilisateurs.class);
		Assert.assertEquals(u, u2);

	}
}